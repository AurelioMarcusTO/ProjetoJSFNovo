package primeiroprojetojsf;

import javax.persistence.Persistence;
import javax.persistence.Table;


public class TesteJPA {
	
	public static void main(String[] args) {
		
		Persistence.createEntityManagerFactory("primeiroprojetojsf");
		
	}

}
